const t=e=>new Date(e).toLocaleDateString("fa-IR");export{t as c};
